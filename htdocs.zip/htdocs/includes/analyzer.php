<?php
const LISTS = [
 'sens'  => ["shocking","unbelievable","you won't believe","miracle","secret","exposed","bombshell","cover-up","hoax","outrage","banned","destroyed","urgent","breaking","wake up","share before","they don't want you to know","conspiracy","scandal","horrifying","jaw-dropping"],
 'abs'   => ["always","never","everyone","nobody","100%","proven","guaranteed","cure","totally","completely","undeniable","every single"],
 'vague' => ["experts say","sources say","people are saying","some say","reportedly","many believe","insiders","anonymous source","rumor","rumour","allegedly","a friend of"],
 'cred'  => ["according to","said","told reporters","reported by","study","published in","university","ministry","official","police","spokesperson","press release","data from","statement","court","research"],
];
function rx(string $k, bool $escaped = false): string {
    $w = array_map(fn($x) => preg_quote($escaped ? htmlspecialchars($x, ENT_QUOTES, 'UTF-8') : $x, '/'), LISTS[$k]);
    return '/(?<![a-z])(' . implode('|', $w) . ')(?![a-z])/iu';
}
function cnt(string $t, string $k): int { return (int)preg_match_all(rx($k), $t); }

function sentence_risk(string $s): array {
    $sens = cnt($s,'sens'); $ab = cnt($s,'abs'); $va = cnt($s,'vague'); $cr = cnt($s,'cred');
    $caps = (int)preg_match_all('/\b[A-Z]{3,}\b/', $s); $ex = substr_count($s, '!');
    $r = $sens*3 + $ab + $va*2 + $ex*1.5 + $caps*1.5 - $cr*2;
    $flags = [];
    if ($sens) $flags[] = 'sensational wording';
    if ($ab) $flags[] = 'absolute claim';
    if ($va) $flags[] = 'vague source';
    if ($caps) $flags[] = 'caps';
    if ($ex) $flags[] = 'exclamation';
    if ($cr) $flags[] = 'cites a source';
    return ['text'=>$s, 'level'=>$r >= 3 ? 'High' : ($r >= 1.5 ? 'Medium' : 'Low'), 'flags'=>$flags];
}

function analyze_text(string $text): array {
    $words = preg_split('/\s+/u', trim($text), -1, PREG_SPLIT_NO_EMPTY);
    $n = max(1, count($words));
    $sens = cnt($text,'sens'); $ab = cnt($text,'abs'); $va = cnt($text,'vague'); $cr = cnt($text,'cred');
    $caps = count(array_filter($words, fn($w) => preg_match('/^[A-Z]{3,}[^a-z]*$/', $w)));
    $capsR = $caps / $n; $ex = substr_count($text, '!');
    $nums = (int)preg_match_all('/\b\d[\d,.%]*\b/', $text);
    $q = (int)preg_match_all('/["\x{201c}][^"\x{201d}]{8,}["\x{201d}]/u', $text);
    $s = 72 - min(30,$sens*7) - ($capsR > .08 ? min(15, round($capsR*80)) : 0) - min(12,$ex*3) - min(12,$ab*4)
       - min(15,$va*5) + min(16,$cr*4) + min(8,$nums*2) + min(6,$q*3) + ($n >= 60 ? 4 : 0);
    $score = (int)max(3, min(97, round($s)));
    $verdict = $score >= 70 ? 'Likely credible' : ($score >= 45 ? 'Needs review' : 'Likely misleading');
    $sents = array_map('sentence_risk', array_values(array_filter(array_map('trim',
        preg_split('/(?<=[.!?])\s+|\n+/u', $text)), fn($x) => mb_strlen($x) > 3)));
    return [
        'score'=>$score, 'verdict'=>$verdict, 'words'=>$n, 'confidence'=>$n < 15 ? 'Low' : ($n < 40 ? 'Medium' : 'High'),
        'sentences'=>$sents,
        'bars'=>[
            ['Sensational wording', min(100,$sens*25), true], ['Shouting (caps)', min(100,(int)round($capsR*500)), true],
            ['Excess punctuation', min(100,$ex*25), true], ['Absolute claims', min(100,$ab*25), true],
            ['Vague sourcing', min(100,$va*33), true], ['Evidence and sourcing', min(100,$cr*20+$q*15+$nums*5), false],
        ],
    ];
}
function highlight(string $text): string {
    $h = htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
    foreach (['sens','abs','vague'] as $k) $h = preg_replace(rx($k, true), '<mark>$1</mark>', $h);
    $h = preg_replace('/(?<![a-z>])(according to|told reporters|reported by|published in|data from|press release|spokesperson)(?![a-z])/i', '<mark class="good">$1</mark>', $h);
    return nl2br($h);
}
function verdict_class(string $v): string {
    if (in_array($v, ['Likely credible','Real','Likely real'], true)) return 'ok';
    if (in_array($v, ['Likely misleading','Likely fake'], true)) return 'bad';
    return 'mid';
}
