</main>
<footer class="foot"><div class="wrap fgrid">
  <div><div class="brand"><span class="logo">N</span><?= APP_NAME ?></div><p class="meta">Real-or-fake news checking for India, powered by multi-source verification and AI. A college project built with PHP, MySQL and the Groq API.</p></div>
  <div><b>Explore</b><a href="index.php">Home</a><a href="analyze.php">Check news</a><a href="about.php">About &amp; method</a><a href="sources.php">Trusted sources</a></div>
  <div><b>Contact</b><a href="contact.php">Contact us</a><span class="meta"><?= e(CONTACT_EMAIL) ?></span><span class="meta">&copy; <?= date('Y') ?> <?= APP_NAME ?></span></div>
</div><div class="wrap meta fdis">AI-assisted fact-checking is a guide, not proof. Always confirm important claims with trusted primary sources.</div></footer>
</body></html>
