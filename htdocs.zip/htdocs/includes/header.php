<?php require_once __DIR__ . '/../config.php'; $u = user(); $page = basename($_SERVER['SCRIPT_NAME']);
$nav = ['index.php'=>'Home', 'analyze.php'=>'Check news', 'about.php'=>'About', 'sources.php'=>'Sources', 'contact.php'=>'Contact']; ?>
<!DOCTYPE html>
<html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title ?? APP_NAME) ?> - <?= APP_NAME ?></title>
<meta name="description" content="Check whether a news story is real or fake using Indian and global sources plus AI fact-checking.">
<link rel="stylesheet" href="assets/style.css">
</head><body>
<nav class="nav"><div class="navin">
  <a class="brand" href="index.php"><span class="logo">N</span><?= APP_NAME ?></a>
  <div class="navlinks">
  <?php foreach ($nav as $f => $lb): ?><a href="<?= $f ?>" class="<?= $page === $f ? 'on' : '' ?>"><?= $lb ?></a><?php endforeach; ?>
  <?php if ($u): ?><a href="history.php" class="<?= $page === 'history.php' ? 'on' : '' ?>">History</a>
    <?php if ($u['role'] === 'admin'): ?><a href="admin.php" class="<?= in_array($page, ['admin.php', 'messages.php'], true) ? 'on' : '' ?>">Admin</a><?php endif; ?><?php endif; ?>
  </div>
  <span class="sp"></span>
  <div class="auth">
  <?php if ($u): ?><span class="meta">Hi, <?= e($u['name']) ?></span><a href="logout.php" class="btn">Log out</a>
  <?php else: ?><a href="login.php" class="btn <?= $page === 'login.php' ? 'on' : '' ?>">Log in</a><a class="btn pri" href="register.php">Register</a><?php endif; ?>
  </div>
</div></nav>
<main class="wrap">
<?php if (!empty($_SESSION['notice'])): ?><p class="note"><?= e($_SESSION['notice']) ?></p><?php unset($_SESSION['notice']); endif; ?>
<?php if (!empty($_SESSION['flash'])): ?><p class="alert"><?= e($_SESSION['flash']) ?></p><?php unset($_SESSION['flash']); endif; ?>
