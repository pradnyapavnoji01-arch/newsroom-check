<?php
/* =====================================================================
   SOURCE ENGINE  -  checks a story against many online news sources.
   No AI is needed for this part, so it is easy to explain in a viva:
     1. Search Google News (India edition) + direct RSS feeds of Indian outlets.
     2. Tag every result: official / Indian news / fact-checker / global / other.
     3. Score how well trusted sources corroborate the story (0-100).
     4. Apply simple, transparent rules to the AI verdict.
   ===================================================================== */

// domain => [display name, type]   types: official | indian | factcheck | global
const TRUSTED = [
 'pib.gov.in'=>['PIB (Govt. of India)','official'], 'ddnews.gov.in'=>['DD News','official'], 'rbi.org.in'=>['Reserve Bank of India','official'],
 'isro.gov.in'=>['ISRO','official'], 'eci.gov.in'=>['Election Commission of India','official'], 'mohfw.gov.in'=>['Ministry of Health (India)','official'], 'who.int'=>['WHO','official'],
 'thehindu.com'=>['The Hindu','indian'], 'thehindubusinessline.com'=>['BusinessLine','indian'], 'indianexpress.com'=>['The Indian Express','indian'],
 'ndtv.com'=>['NDTV','indian'], 'timesofindia.indiatimes.com'=>['Times of India','indian'], 'economictimes.indiatimes.com'=>['Economic Times','indian'],
 'hindustantimes.com'=>['Hindustan Times','indian'], 'indiatoday.in'=>['India Today','indian'], 'livemint.com'=>['Mint','indian'],
 'business-standard.com'=>['Business Standard','indian'], 'news18.com'=>['News18','indian'], 'theprint.in'=>['ThePrint','indian'], 'scroll.in'=>['Scroll.in','indian'],
 'thewire.in'=>['The Wire','indian'], 'deccanherald.com'=>['Deccan Herald','indian'], 'telegraphindia.com'=>['The Telegraph India','indian'], 'tribuneindia.com'=>['The Tribune','indian'],
 'newindianexpress.com'=>['The New Indian Express','indian'], 'firstpost.com'=>['Firstpost','indian'], 'thequint.com'=>['The Quint','indian'], 'aajtak.in'=>['Aaj Tak','indian'],
 'abplive.com'=>['ABP Live','indian'], 'zeenews.india.com'=>['Zee News','indian'], 'ptinews.com'=>['PTI','indian'], 'aninews.in'=>['ANI','indian'], 'lokmat.com'=>['Lokmat','indian'],
 'loksatta.com'=>['Loksatta','indian'], 'maharashtratimes.com'=>['Maharashtra Times','indian'], 'esakal.com'=>['eSakal','indian'], 'mid-day.com'=>['Mid-day','indian'],
 'outlookindia.com'=>['Outlook India','indian'], 'deccanchronicle.com'=>['Deccan Chronicle','indian'], 'jagran.com'=>['Dainik Jagran','indian'], 'bhaskar.com'=>['Dainik Bhaskar','indian'],
 'amarujala.com'=>['Amar Ujala','indian'],
 'altnews.in'=>['Alt News','factcheck'], 'boomlive.in'=>['BOOM','factcheck'], 'newschecker.in'=>['Newschecker','factcheck'], 'factly.in'=>['Factly','factcheck'],
 'vishvasnews.com'=>['Vishvas News','factcheck'], 'factcrescendo.com'=>['Fact Crescendo','factcheck'], 'digiteye.in'=>['DigitEye India','factcheck'],
 'snopes.com'=>['Snopes','factcheck'], 'factcheck.org'=>['FactCheck.org','factcheck'], 'politifact.com'=>['PolitiFact','factcheck'], 'factcheck.afp.com'=>['AFP Fact Check','factcheck'],
 'reuters.com'=>['Reuters','global'], 'apnews.com'=>['Associated Press','global'], 'bbc.com'=>['BBC','global'], 'bbc.co.uk'=>['BBC','global'], 'aljazeera.com'=>['Al Jazeera','global'],
 'theguardian.com'=>['The Guardian','global'], 'nytimes.com'=>['The New York Times','global'], 'washingtonpost.com'=>['The Washington Post','global'], 'bloomberg.com'=>['Bloomberg','global'],
 'cnn.com'=>['CNN','global'], 'dw.com'=>['DW','global'],
];
const TYPE_LABELS = ['official'=>'Government / official', 'indian'=>'Indian news', 'factcheck'=>'Fact-checker', 'global'=>'Global news', 'other'=>'Other'];

// Direct RSS feeds of Indian outlets (latest headlines). Broken feeds are skipped automatically - edit freely.
const FEEDS = [
 'The Hindu' => 'https://www.thehindu.com/news/national/feeder/default.rss',
 'The Indian Express' => 'https://indianexpress.com/section/india/feed/',
 'NDTV' => 'https://feeds.feedburner.com/ndtvnews-latest',
 'Times of India' => 'https://timesofindia.indiatimes.com/rssfeeds/-2128936835.cms',
 'Hindustan Times' => 'https://www.hindustantimes.com/feeds/rss/india-news/rssfeed.xml',
 'India Today' => 'https://www.indiatoday.in/rss/1206514',
 'PIB (Govt. of India)' => 'https://pib.gov.in/RssMain.aspx?ModId=6&Lang=1&Regid=3',
];
const DEBUNK_RX = '/\b(fake|false|misleading|hoax|baseless|debunk\w*|not true|untrue|fabricated|doctored|morphed|misattributed|old video|unrelated|satire|no,)\b/i';

function trusted_info(string $host): ?array {
    $host = strtolower(preg_replace('/^www\./', '', $host));
    foreach (TRUSTED as $d => $info) if ($host === $d || str_ends_with($host, '.' . $d)) return $info;
    return null;
}

function heuristic_query(string $body, ?string $title): string {
    $q = ($title && mb_strlen($title) > 15) ? $title : (preg_split('/(?<=[.!?])\s+/u', trim($body), 2)[0] ?? $body);
    return mb_substr(trim(preg_replace('/\s+/u', ' ', $q)), 0, 110);
}

function query_tokens(string $q): array {
    $stop = ['that','this','with','from','have','been','were','will','about','after','their','there','which','would','could','says','said','news'];
    $w = preg_split('/[^\p{L}\p{N}]+/u', mb_strtolower($q), -1, PREG_SPLIT_NO_EMPTY);
    return array_values(array_unique(array_filter($w, fn($x) => mb_strlen($x) > 3 && !in_array($x, $stop, true))));
}
function title_matches(string $title, array $tok): bool {
    if (count($tok) < 2) return false;
    $t = mb_strtolower($title); $hit = 0;
    foreach ($tok as $w) if (str_contains($t, $w)) $hit++;
    return $hit >= 2 && $hit >= 0.4 * count($tok);
}

function sites(array $domains): string { return '(' . implode(' OR ', array_map(fn($d) => "site:$d", $domains)) . ')'; }
function evidence_queries(string $q, bool $recent): array {
    $w = fn($d) => $recent ? " when:$d" : '';
    return [
        ['indian',    "$q " . sites(['thehindu.com','indianexpress.com','ndtv.com','timesofindia.indiatimes.com','hindustantimes.com','indiatoday.in','livemint.com','news18.com','theprint.in','business-standard.com','pib.gov.in','deccanherald.com']) . $w('30d')],
        ['factcheck', "$q " . sites(['altnews.in','boomlive.in','newschecker.in','factly.in','vishvasnews.com','factcrescendo.com','thequint.com']) . $w('180d')],
        ['global',    "$q " . sites(['reuters.com','apnews.com','bbc.com','aljazeera.com']) . $w('30d')],
        ['general',   "$q" . $w('30d')],
    ];
}

function fetch_many(array $urls, int $timeout = 12): array {
    $mh = curl_multi_init(); $hs = []; $out = [];
    foreach ($urls as $k => $u) {
        $ch = curl_init($u);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_TIMEOUT=>$timeout, CURLOPT_FOLLOWLOCATION=>true, CURLOPT_MAXREDIRS=>3, CURLOPT_ENCODING=>'',
            CURLOPT_USERAGENT=>'Mozilla/5.0 (compatible; NewsroomCheck/3.0)']);
        if (CA_BUNDLE) curl_setopt($ch, CURLOPT_CAINFO, CA_BUNDLE);
        curl_multi_add_handle($mh, $ch); $hs[$k] = $ch;
    }
    do { $st = curl_multi_exec($mh, $run); if ($run) curl_multi_select($mh, 1.0); } while ($run && $st === CURLM_OK);
    foreach ($hs as $k => $ch) { $out[$k] = (string)curl_multi_getcontent($ch); curl_multi_remove_handle($mh, $ch); curl_close($ch); }
    curl_multi_close($mh);
    return $out;
}

function parse_feed(string $raw, string $group, string $feedName = ''): array {
    if ($raw === '') return [];
    libxml_use_internal_errors(true);
    $x = @simplexml_load_string($raw);
    if (!$x || !isset($x->channel->item)) return [];
    $out = [];
    foreach ($x->channel->item as $it) {
        $title = trim(html_entity_decode(strip_tags((string)$it->title), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
        $link = trim((string)$it->link); $src = trim((string)$it->source);
        if ($src !== '') {                                   // Google News item
            $host = (string)(parse_url((string)$it->source['url'], PHP_URL_HOST) ?: '');
            if (str_ends_with($title, ' - ' . $src)) $title = substr($title, 0, -(strlen($src) + 3));
        } else { $host = (string)(parse_url($link, PHP_URL_HOST) ?: ''); $src = $feedName; }   // direct feed
        $ts = strtotime((string)$it->pubDate) ?: 0; $info = trusted_info($host);
        $fc = ($info && $info[1] === 'factcheck') || (bool)preg_match('/fact[\s-]?check|webqoof|vishvas/i', $title);
        $out[] = ['title'=>$title, 'source'=>$info[0] ?? ($src ?: $host), 'host'=>$host, 'url'=>$link, 'ts'=>$ts, 'date'=>$ts ? date('Y-m-d', $ts) : '',
                  'type'=>$info[1] ?? 'other', 'fc'=>$fc, 'debunk'=>$fc && (bool)preg_match(DEBUNK_RX, $title), 'group'=>$group];
    }
    return $out;
}

function collect_evidence(string $q): array {
    $tok = query_tokens($q); $items = [];
    $gurl = fn($qq) => 'https://news.google.com/rss/search?hl=en-IN&gl=IN&ceid=IN:en&q=' . urlencode($qq);
    $urls = [];
    foreach (evidence_queries($q, true) as $i => [$g, $qq]) $urls["g|$g|$i"] = $gurl($qq);
    foreach (FEEDS as $name => $u) $urls["f|$name"] = $u;
    $gotGoogle = false;
    foreach (fetch_many($urls) as $k => $raw) {
        $p = explode('|', $k, 3);
        if ($p[0] === 'g') { $r = parse_feed($raw, $p[1]); $gotGoogle = $gotGoogle || $r; $items = array_merge($items, $r); }
        else foreach (parse_feed($raw, 'direct', $p[1]) as $it) if (title_matches($it['title'], $tok)) $items[] = $it;
    }
    if (!$gotGoogle) {                                       // older story? search again without the time limit
        $urls = []; foreach (evidence_queries($q, false) as $i => [$g, $qq]) $urls["g|$g|$i"] = $gurl($qq);
        foreach (fetch_many($urls) as $k => $raw) $items = array_merge($items, parse_feed($raw, explode('|', $k, 3)[1]));
    }
    $seen = []; $u = [];
    foreach ($items as $it) { $key = preg_replace('/[^a-z0-9]+/', '', strtolower($it['title'])); if ($key === '' || isset($seen[$key])) continue; $seen[$key] = 1; $u[] = $it; }
    $rank = ['official'=>0, 'indian'=>1, 'factcheck'=>1, 'global'=>2, 'other'=>3];
    usort($u, fn($a, $b) => ($rank[$a['type']] <=> $rank[$b['type']]) ?: ($b['ts'] <=> $a['ts']));
    $u = array_slice($u, 0, 30);
    return ['query'=>$q, 'items'=>$u, 'stats'=>score_evidence($u)];
}

function score_evidence(array $items): array {
    $news = $ind = $off = $fc = []; $debunk = $recent = 0; $now = time();
    foreach ($items as $it) {
        if ($it['fc']) { $fc[$it['source']] = 1; if ($it['debunk']) $debunk++; }
        if (in_array($it['type'], ['indian', 'global', 'official'], true)) {
            $news[$it['source']] = 1;
            if ($it['type'] !== 'global') $ind[$it['source']] = 1;
            if ($it['type'] === 'official') $off[$it['source']] = 1;
            if ($it['ts'] && $now - $it['ts'] <= 7 * 86400) $recent++;
        }
    }
    $n = count($news);
    $score = [0, 20, 35, 50, 60][min($n, 4)] + ($off ? 15 : 0) + ($recent ? 10 : 0) + (count($ind) >= 2 ? 15 : 0);
    return ['trusted_outlets'=>$n, 'indian_outlets'=>count($ind), 'official'=>count($off), 'factcheckers'=>count($fc), 'debunk'=>$debunk,
            'recent'=>$recent, 'total'=>count($items), 'score'=>min(100, $score)];
}

function evidence_for_prompt(array $ev): string {
    $o = "AUTOMATED SOURCE SEARCH (query: \"{$ev['query']}\"; Google News India + direct RSS of Indian outlets):\n";
    if (!$ev['items']) return $o . "No matching articles were found in any source.\n";
    foreach (array_slice($ev['items'], 0, 24) as $it) $o .= '- [' . strtoupper($it['fc'] ? 'fact-check' : $it['type']) . '] ' . $it['title'] . ' | ' . $it['source'] . ' | ' . $it['date'] . "\n";
    $s = $ev['stats'];
    $o .= "Summary: {$s['trusted_outlets']} trusted outlets ({$s['indian_outlets']} Indian), {$s['factcheckers']} fact-checkers, {$s['debunk']} debunk-style headlines, {$s['recent']} trusted items in the last 7 days.\n";
    return $o . "Caution: a headline may be about a DIFFERENT but similar story, or may itself report that a claim is false. Read carefully.\n";
}

// Transparent rules that can only make a verdict MORE cautious (or flag a likely AI over-reaction).
function adjust_verdict(array $r, array $ev): array {
    $s = $ev['stats']; $v = $r['verdict']; $note = ''; $r['ai_score'] = $r['score'];
    $score = (int)round(0.7 * $r['score'] + 0.3 * $s['score']);
    if (($r['category'] ?? 'news') === 'news') {
        if ($s['debunk'] > 0 && in_array($v, ['real', 'likely_real'], true)) { $v = 'mixed'; $score = min($score, 45); $note = 'Downgraded: an Indian/international fact-checker published a "false/misleading" headline on a matching story.'; }
        elseif ($s['trusted_outlets'] === 0 && in_array($v, ['real', 'likely_real'], true)) { $v = 'unverifiable'; $score = min($score, 50); $note = 'Downgraded: no trusted Indian or global outlet was found reporting this recently.'; }
        elseif ($s['trusted_outlets'] === 1 && $v === 'real') { $v = 'likely_real'; $note = 'Capped at "Likely real": only one trusted outlet was found.'; }
        elseif ($v === 'likely_fake' && $s['trusted_outlets'] >= 3 && $s['debunk'] === 0) { $v = 'mixed'; $note = 'Softened: the AI raised concerns, but 3+ trusted outlets report this story and no fact-checker disputes it. Review the evidence yourself.'; }
    }
    $r['verdict'] = $v; $r['label'] = VERDICT_LABELS[$v]; $r['score'] = max(0, min(100, $score)); $r['adjustment'] = $note;
    return $r;
}

// Used when the AI is unavailable: a verdict from source evidence alone.
function evidence_only_result(array $ev, array $style): array {
    $s = $ev['stats']; $n = $s['trusted_outlets'];
    if ($s['debunk'] > 0) { $v = 'mixed'; $sum = 'Fact-checkers have published "false/misleading" headlines on a matching story. Treat this claim with caution.'; }
    elseif ($n >= 3) { $v = 'likely_real'; $sum = "$n trusted outlets ({$s['indian_outlets']} Indian) report a matching story and no fact-checker disputes it."; }
    elseif ($n === 0 && $style['score'] < 45) { $v = 'likely_fake'; $sum = 'No trusted outlet reports this, and the writing shows strong sensational / unsourced patterns.'; }
    else { $v = 'unverifiable'; $sum = $n ? "Only $n trusted outlet(s) matched, which is not enough to confirm it." : 'No trusted Indian or global outlet was found reporting this recently.'; }
    return ['verdict'=>$v, 'label'=>VERDICT_LABELS[$v], 'score'=>$v === 'mixed' ? min(45, $s['score']) : ($v === 'likely_fake' ? min(25, $style['score']) : $s['score']),
        'ai_score'=>null, 'confidence'=>$n >= 3 ? 70 : 45, 'category'=>'news', 'headline'=>'Verdict based on source evidence (AI unavailable)', 'summary'=>$sum,
        'claims'=>[], 'red_flags'=>[], 'positive_signals'=>[], 'verify_next'=>['Open the matching articles listed below and compare the facts.', 'Search the headline on pib.gov.in or the outlet websites directly.'],
        'sources'=>[], 'web'=>false, 'model'=>'rule-based (no AI)', 'adjustment'=>'', 'evidence'=>$ev];
}
